
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","FlorianWolters\\Component\\Core\\EqualityInterface"],["c","FlorianWolters\\Component\\Core\\EqualityUtils"],["c","FlorianWolters\\Component\\Core\\ReferenceEqualityTrait"],["c","FlorianWolters\\Component\\Core\\ValueEqualityTrait"]];
