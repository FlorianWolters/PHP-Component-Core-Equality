
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","FlorianWolters\\Component\\Core\\EqualityInterface"],["c","FlorianWolters\\Component\\Core\\EqualityTrait"],["c","FlorianWolters\\Component\\Core\\EqualityUtils"],["f","is_equal()"]];
